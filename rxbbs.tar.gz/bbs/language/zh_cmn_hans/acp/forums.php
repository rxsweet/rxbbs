<?php
/**
*
* This file is part of the phpBB Forum Software package.
* @简体中文语言　David Yin <https://www.phpbbchinese.com/>
* @copyright (c) phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
* For full copyright and license information, please see
* the docs/CREDITS.txt file.
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

// Forum Admin
$lang = array_merge($lang, array(
	'AUTO_PRUNE_DAYS'			=> '根据回帖时间来裁减旧主题',
	'AUTO_PRUNE_DAYS_EXPLAIN'	=> '在最后一个回帖发表后多少天这个主题会被删除。',
	'AUTO_PRUNE_FREQ'			=> '裁减旧主题的频率',
	'AUTO_PRUNE_FREQ_EXPLAIN'	=> '多久执行一次旧主题自动裁剪。',
	'AUTO_PRUNE_VIEWED'			=> '根据查看帖子时间来裁减旧主题',
	'AUTO_PRUNE_VIEWED_EXPLAIN'	=> '在帖子最后被查看后多少天后这个主题会被删除。',
	'AUTO_PRUNE_SHADOW_FREQ'	=> '自动裁剪影子主题频率',
	'AUTO_PRUNE_SHADOW_DAYS'	=> '根据时间来自动裁剪影子主题',
	'AUTO_PRUNE_SHADOW_DAYS_EXPLAIN'	=> '多少天后移除影子主题。',
	'AUTO_PRUNE_SHADOW_FREQ_EXPLAIN'	=> '多久执行一次自动裁剪。',

	'CONTINUE'						=> '继续',
	'COPY_PERMISSIONS'				=> '从何处复制权限',
	'COPY_PERMISSIONS_EXPLAIN'		=> '为了方便新版面的权限设置，您可以复制一个现有的版面权限至新版面。',
	'COPY_PERMISSIONS_ADD_EXPLAIN'	=> '一旦创建，这个版面将拥有您选择的版面同样的权限。如果没有选中，新的版面在权限设置前将是不显示的。',
	'COPY_PERMISSIONS_EDIT_EXPLAIN'	=> '如果您选择了复制权限，版面将拥有您选择的版面同样的权限。这将覆盖您原先设置的权限。如果没有选中，将保留原有权限。',
	'COPY_TO_ACL'					=> '另外，您也可以为这个版面 %s 设定新权限 %s 。',
	'CREATE_FORUM'					=> '创建新版面',

	'DECIDE_MOVE_DELETE_CONTENT'		=> '删除或移动到版面',
	'DECIDE_MOVE_DELETE_SUBFORUMS'		=> '删除子版面或移动到版面',
	'DEFAULT_STYLE'						=> '默认样式',
	'DELETE_ALL_POSTS'					=> '删除帖子',
	'DELETE_SUBFORUMS'					=> '删除子版面和帖子',
	'DISPLAY_ACTIVE_TOPICS'				=> '启用活跃帖子功能',
	'DISPLAY_ACTIVE_TOPICS_EXPLAIN'		=> '如果设置为是，在选中的子版面中活跃的帖子将会显示在这个分区下。',

	'EDIT_FORUM'					=> '编辑版面',
	'ENABLE_INDEXING'				=> '启用搜索索引',
	'ENABLE_INDEXING_EXPLAIN'		=> '如果设置为是, 这个版面的帖子将被编入搜索索引。',
	'ENABLE_POST_REVIEW'			=> '允许预览帖子',
	'ENABLE_POST_REVIEW_EXPLAIN'	=> '如果设置为是，当用户在编写帖子时有新的帖子发布，用户可以预览他们的帖子。这在对话型版面中应该禁用。',
	'ENABLE_QUICK_REPLY'			=> '启用快速回复',
	'ENABLE_QUICK_REPLY_EXPLAIN'	=> '启用后用户在这个版面可以通过快速回复来回复文章。如果论坛功能中停用了快速回复，这里的选项将不起作用。',
	'ENABLE_RECENT'					=> '显示活跃帖子',
	'ENABLE_RECENT_EXPLAIN'			=> '如果设置为是，这个版面的话题将显示在活跃帖子列表中。',
	'ENABLE_TOPIC_ICONS'			=> '允许主题图标',

	'FORUM_ADMIN'						=> '版面管理',
	'FORUM_ADMIN_EXPLAIN'				=> '在 phpBB3 中一切都是基于版面。 分区只是特殊的版面。每个版面可以拥有无限的子版面并且您可以决定哪些能发帖哪些不能（例如是否像一个旧分区）。这里您能添加、编辑、删除、锁定、解锁单独版面并适当设置一些额外控制。如果您的帖子和主题失去同步，您可以重新同步一下版面。<strong>要显示新创建的版面，您需要为它复制或设置适当的权限。</strong>',
	'FORUM_AUTO_PRUNE'					=> '开启自动裁减',
	'FORUM_AUTO_PRUNE_EXPLAIN'			=> '裁减版面的主题，在下面设置频率/时间参数。',
	'FORUM_CREATED'						=> '版面创建成功。',
	'FORUM_DATA_NEGATIVE'				=> '裁减参数不能为负。',
	'FORUM_DESC_TOO_LONG'				=> '版面描述太长，不能超过4000字符。',
	'FORUM_DELETE'						=> '删除版面',
	'FORUM_DELETE_EXPLAIN'				=> '下面的表单允许您删除一个版面。如果这个版面允许发帖，您可以决定如何处置这个版面中的子版面和文章。',
	'FORUM_DELETED'						=> '版面删除完成。',
	'FORUM_DESC'						=> '版面描述',
	'FORUM_DESC_EXPLAIN'				=> '任何这里的文字都会原样显示。如果选的版面类型是分区，描述将不会显示。',
	'FORUM_EDIT_EXPLAIN'				=> '下面的表单允许您自定义这个版面。请注意版面管理和帖子数控制要通过每个用户或用户组的权限来控制。',
	'FORUM_IMAGE'						=> '版面图标',
	'FORUM_IMAGE_EXPLAIN'				=> '添加一个和版面相关联的图标，其地址需使用论坛根目录的相对路径。',
	'FORUM_IMAGE_NO_EXIST'            	=> '指定的版面图标不存在',
	'FORUM_LINK_EXPLAIN'				=> '用户点击这个版面后前往的完整URL (包含协议头，例如 <samp>http://</samp>)。',
	'FORUM_LINK_TRACK'					=> '跟踪链接重定向',
	'FORUM_LINK_TRACK_EXPLAIN'			=> '记录链接的被点击的次数。',
	'FORUM_NAME'						=> '版面名称',
	'FORUM_NAME_EMPTY'					=> '您必须为这个版面取个名字。',
	'FORUM_NAME_EMOJI'					=> '您输入的版面名称无效。<br>它包含了下面不支持的字符：<br>%s',
	'FORUM_PARENT'						=> '父版面',
	'FORUM_PASSWORD'					=> '版面密码',
	'FORUM_PASSWORD_CONFIRM'			=> '确认版面密码',
	'FORUM_PASSWORD_CONFIRM_EXPLAIN'	=> '您输入了版面密码才需要在这里再次输入。',
	'FORUM_PASSWORD_EXPLAIN'			=> '设置这个版面的访问密码, 但最好使用权限系统。',
	'FORUM_PASSWORD_UNSET'				=> '删除版面密码',
	'FORUM_PASSWORD_UNSET_EXPLAIN'		=> '如果您希望删除版面密码请勾选此处。',
	'FORUM_PASSWORD_OLD'				=> '当前版面密码使用的是旧的加密方式，需要立即更改。',
	'FORUM_PASSWORD_MISMATCH'			=> '您输入的密码不匹配。',
	'FORUM_PRUNE_SETTINGS'				=> '版面裁减设定',
	'FORUM_PRUNE_SHADOW'				=> '启用自动裁剪影子主题',
	'FORUM_PRUNE_SHADOW_EXPLAIN'		=> '裁剪影子主题，设置下面的频率/时期参数。',
	'FORUM_RESYNCED'					=> '版面 “%s” 同步完成',
	'FORUM_RULES_EXPLAIN'				=> '版面规则将在版面的所有页面显示。',
	'FORUM_RULES_LINK'					=> '版面规则链接',
	'FORUM_RULES_LINK_EXPLAIN'			=> '您可以在这里输入包含版面规则的链接。这个设定将覆盖版面文字规则。',
	'FORUM_RULES_PREVIEW'				=> '版面规则预览',
	'FORUM_RULES_TOO_LONG'				=> '版面规则不能超过4000个字符。',
	'FORUM_SETTINGS'					=> '版面设定',
	'FORUM_STATUS'						=> '版面状态',
	'FORUM_STYLE'						=> '版面风格',
	'FORUM_TOPICS_PAGE'					=> '每页主题数',
	'FORUM_TOPICS_PAGE_EXPLAIN'			=> '如果非 0，此数值将覆盖默认的每页主题数。',
	'FORUM_TYPE'						=> '版面类型',
	'FORUM_UPDATED'						=> '版面信息更新完成。',

	'FORUM_WITH_SUBFORUMS_NOT_TO_LINK'		=> '您正试图将一个拥有子版面的普通版面改变为链接。请在继续之前将全部子版面移出，因为在您将它变为链接之后将无法看到它的子版面。',

	'GENERAL_FORUM_SETTINGS'	=> '版面综合设定',

	'LINK'						=> '链接',
	'LIMIT_SUBFORUMS'			=> '直接子论坛图标的限制',
	'LIMIT_SUBFORUMS_EXPLAIN'	=> '只显示论坛的直接子论坛。停用此选项将显示所有的子论坛，只要该子论坛启用了“在图例中显示子版面”的选项，而无论不限制其子论坛的深度。',

	'LIST_INDEX'				=> '在子版面列表中显示',
	'LIST_INDEX_EXPLAIN'		=> '在父版面的子版面列表中显示一个指向本版面的链接和图标，其父版面需要启用“在图例中显示子版面”。',
	'LIST_SUBFORUMS'			=> '在图例中显示子版面',
	'LIST_SUBFORUMS_EXPLAIN'	=> '如果启用此选项，就会在首页或其他页面的图例中显示子版面的链接。',
	'LOCKED'				=> '锁定',

	'MOVE_POSTS_NO_POSTABLE_FORUM'	=> '您选中移动的目标版面不可发表文章。请选择其他的版面。',
	'MOVE_POSTS_TO'		=> '移动帖子到',
	'MOVE_SUBFORUMS_TO'	=> '移动子版面到',

	'NO_DESTINATION_FORUM'			=> '您没有指定移动操作的目标版面',
	'NO_FORUM_ACTION'				=> '没有在版面处理中指定操作',
	'NO_PARENT'						=> '没有父版面',
	'NO_PERMISSIONS'				=> '不复制权限',
	'NO_PERMISSION_FORUM_ADD'		=> '您没有增加版面的权限。',
	'NO_PERMISSION_FORUM_DELETE'	=> '您没有删除版面的权限。',

	'PARENT_IS_LINK_FORUM'		=> '您指定的父版面是一个版面链接。版面链接不能包含其它的版面，请另外指定分区或版面作为父版面。',
	'PARENT_NOT_EXIST'			=> '父版面不存在。',
	'PRUNE_ANNOUNCEMENTS'		=> '裁减公告',
	'PRUNE_STICKY'				=> '裁减置顶',
	'PRUNE_OLD_POLLS'			=> '裁减旧投票',
	'PRUNE_OLD_POLLS_EXPLAIN'	=> '移除在帖子的活跃天数内没有新投票的投票。',

	'REDIRECT_ACL'	=> '下一步您可以对这个论坛 %s设置权限%s。',

	'SYNC_IN_PROGRESS'			=> '正在同步版面',
	'SYNC_IN_PROGRESS_EXPLAIN'	=> '正在同步主题范围 %1$d/%2$d。',

	'TYPE_CAT'			=> '分区',
	'TYPE_FORUM'		=> '版面',
	'TYPE_LINK'			=> '链接',

	'UNLOCKED'			=> '未锁定',
));

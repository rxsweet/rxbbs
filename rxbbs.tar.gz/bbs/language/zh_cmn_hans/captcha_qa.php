<?php
/**
*
* This file is part of the phpBB Forum Software package.
* @简体中文语言　David Yin <https://www.phpbbchinese.com/>
* @copyright (c) phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
* For full copyright and license information, please see
* the docs/CREDITS.txt file.
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'CAPTCHA_QA'				=> 'Q&amp;A',
	'CONFIRM_QUESTION_EXPLAIN'	=> '此问题是为了防止垃圾机器人自动提交表单。',
	'CONFIRM_QUESTION_WRONG'	=> '您的回答不正确。',
	'CONFIRM_QUESTION_MISSING'	=> '无法读取 Captcha 验证问题。请联系论坛管理员。',
	
	'QUESTION_ANSWERS'			=> '问题答案',
	'ANSWERS_EXPLAIN'			=> '请输入正确答案， 多个请分行。',
	'CONFIRM_QUESTION'			=> '问题',

	'ANSWER'					=> '答案',
	'EDIT_QUESTION'				=> '编辑问题',
	'QUESTIONS'					=> '问题',
	'QUESTIONS_EXPLAIN'			=> '在每个您所启用的 Q&amp;A 验证插件的表单提交中（包括注册）， 用户会被问及您设定的问题之一。 要使用这个插件， 您在论坛默认语言下要设置至少一个问题。 这个问题必须让您的访客易于理解和回答而机器人无法理解。 请注意， 机器人可能使用Google™ 搜索这类工具来搜索答案。实际使用中，一个适当的问题就足够。如果您发现开始有机器人注册，那就必须修改问题。 您可以设置严格校验来检查答案的标点，空格和大小写是否一致。',
	'QUESTION_DELETED'			=> '问题已删除',
	'QUESTION_LANG'				=> '语言',
	'QUESTION_LANG_EXPLAIN'		=> '这个问题和对应的答案所使用的语言。',
	'QUESTION_STRICT'			=> '严格校验',
	'QUESTION_STRICT_EXPLAIN'	=> '启用后， 大小写，标点和空格一致的答案才能通过验证。',

	'QUESTION_TEXT'				=> '问题内容',
	'QUESTION_TEXT_EXPLAIN'		=> '显示给用户看的问题内容。',

	'QA_ERROR_MSG'				=> '请填写所有字段并输入至少一个答案。',
	'QA_LAST_QUESTION'			=> '在插件还处于激活状态时不能删除所有问题。',
));

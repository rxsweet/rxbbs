<?php exit; ?>
1765077809
SELECT forum_id FROM phpbb_forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}
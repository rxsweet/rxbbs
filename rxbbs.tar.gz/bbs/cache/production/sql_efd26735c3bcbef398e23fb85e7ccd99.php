<?php exit; ?>
1767851699
SELECT forum_id FROM phpbb_forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}
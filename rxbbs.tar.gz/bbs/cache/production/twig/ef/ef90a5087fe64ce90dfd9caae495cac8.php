<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* viewtopic_print.html */
class __TwigTemplate_0ff93f3a5a4b5294271611fe93b7801b extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html dir=\"";
        // line 2
        echo ($context["S_CONTENT_DIRECTION"] ?? null);
        echo "\" lang=\"";
        echo ($context["S_USER_LANG"] ?? null);
        echo "\">
<head>
<meta charset=\"utf-8\" />
<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
<meta name=\"robots\" content=\"noindex\" />
";
        // line 7
        echo ($context["META"] ?? null);
        echo "
<title>";
        // line 8
        echo ($context["SITENAME"] ?? null);
        echo " &bull; ";
        echo ($context["PAGE_TITLE"] ?? null);
        echo "</title>

<link href=\"";
        // line 10
        echo ($context["T_THEME_PATH"] ?? null);
        echo "/print.css\" rel=\"stylesheet\">
";
        // line 11
        if ((($context["S_CONTENT_DIRECTION"] ?? null) == "rtl")) {
            // line 12
            echo "\t<link href=\"";
            echo ($context["T_THEME_PATH"] ?? null);
            echo "/bidi.css\" rel=\"stylesheet\">
";
        }
        // line 14
        // line 15
        echo "</head>
<body id=\"phpbb\" class=\"";
        // line 16
        echo ($context["S_CONTENT_DIRECTION"] ?? null);
        echo "\">
<div id=\"wrap\" class=\"wrap\">
\t<a id=\"top\" class=\"top-anchor\" accesskey=\"t\"></a>

\t<div id=\"page-header\">
\t\t<h1>";
        // line 21
        echo ($context["SITENAME"] ?? null);
        echo "</h1>
\t\t<p>";
        // line 22
        echo ($context["SITE_DESCRIPTION"] ?? null);
        echo "<br /><a href=\"";
        echo ($context["U_FORUM"] ?? null);
        echo "\">";
        echo ($context["U_FORUM"] ?? null);
        echo "</a></p>

\t\t<h2>";
        // line 24
        echo ($context["TOPIC_TITLE"] ?? null);
        echo "</h2>
\t\t<p><a href=\"";
        // line 25
        echo ($context["U_TOPIC"] ?? null);
        echo "\">";
        echo ($context["U_TOPIC"] ?? null);
        echo "</a></p>
\t</div>

\t<div id=\"page-body\" class=\"page-body\">
\t\t<div class=\"page-number\">";
        // line 29
        echo ($context["PAGE_NUMBER"] ?? null);
        echo "</div>
\t\t";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["loops"] ?? null), "postrow", [], "any", false, false, false, 30));
        foreach ($context['_seq'] as $context["_key"] => $context["postrow"]) {
            // line 31
            echo "\t\t\t<div class=\"post\">
\t\t\t\t<h3>";
            // line 32
            echo twig_get_attribute($this->env, $this->source, $context["postrow"], "POST_SUBJECT", [], "any", false, false, false, 32);
            echo "</h3>
\t\t\t\t<div class=\"date\">";
            // line 33
            echo $this->extensions['phpbb\template\twig\extension']->lang("POSTED");
            echo $this->extensions['phpbb\template\twig\extension']->lang("COLON");
            echo " <strong>";
            echo twig_get_attribute($this->env, $this->source, $context["postrow"], "POST_DATE", [], "any", false, false, false, 33);
            echo "</strong></div>
\t\t\t\t<div class=\"author\">";
            // line 34
            echo $this->extensions['phpbb\template\twig\extension']->lang("POST_BY_AUTHOR");
            echo " <strong>";
            echo twig_get_attribute($this->env, $this->source, $context["postrow"], "POST_AUTHOR", [], "any", false, false, false, 34);
            echo "</strong></div>
\t\t\t\t<div class=\"content\">";
            // line 35
            echo twig_get_attribute($this->env, $this->source, $context["postrow"], "MESSAGE", [], "any", false, false, false, 35);
            echo "</div>
\t\t\t</div>
\t\t\t<hr />
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['postrow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "\t</div>

\t<div id=\"page-footer\" class=\"page-footer\">
\t\t<div class=\"page-number\">";
        // line 42
        echo ($context["S_TIMEZONE"] ?? null);
        echo "<br />";
        echo ($context["PAGE_NUMBER"] ?? null);
        echo "</div>
\t\t\t<div class=\"copyright\">
\t\t\t\t<p>";
        // line 44
        echo ($context["CREDIT_LINE"] ?? null);
        echo "
\t\t\t\t</p>
\t\t\t\t";
        // line 46
        if (($context["TRANSLATION_INFO"] ?? null)) {
            // line 47
            echo "\t\t\t\t<p>";
            echo ($context["TRANSLATION_INFO"] ?? null);
            echo "
\t\t\t\t</p>
\t\t\t\t";
        }
        // line 50
        echo "\t\t\t</div>
\t</div>
</div>

</body>
</html>
";
    }

    public function getTemplateName()
    {
        return "viewtopic_print.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 50,  168 => 47,  166 => 46,  161 => 44,  154 => 42,  149 => 39,  139 => 35,  133 => 34,  126 => 33,  122 => 32,  119 => 31,  115 => 30,  111 => 29,  102 => 25,  98 => 24,  89 => 22,  85 => 21,  77 => 16,  74 => 15,  73 => 14,  67 => 12,  65 => 11,  61 => 10,  54 => 8,  50 => 7,  40 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "viewtopic_print.html", "");
    }
}

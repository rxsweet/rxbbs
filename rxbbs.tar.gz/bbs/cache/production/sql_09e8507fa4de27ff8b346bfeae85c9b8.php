<?php exit; ?>
1766306635
SELECT smiley_id FROM phpbb_smilies WHERE display_on_posting = 0 LIMIT 1
6
a:0:{}
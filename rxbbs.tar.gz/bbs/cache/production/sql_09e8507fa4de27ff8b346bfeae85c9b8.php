<?php exit; ?>
1768189508
SELECT smiley_id FROM phpbb_smilies WHERE display_on_posting = 0 LIMIT 1
6
a:0:{}